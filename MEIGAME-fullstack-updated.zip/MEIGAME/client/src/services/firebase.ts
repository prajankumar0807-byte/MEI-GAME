import { getAnalytics, isSupported } from 'firebase/analytics';
import { getApp, getApps, initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';

// Firebase Web SDK configuration supplied for the MEIGAME project (mei-quiz).
// These values are safe to use in browser code; Firebase security is enforced
// by Authentication, Firestore/Storage Rules, and the trusted backend.
const firebaseConfig = {
  apiKey: 'AIzaSyAsvaVnJ4HrYRFFl8q1vhfGnZJ9i-KUOOs',
  authDomain: 'mei-quiz.firebaseapp.com',
  projectId: 'mei-quiz',
  storageBucket: 'mei-quiz.firebasestorage.app',
  messagingSenderId: '508557407988',
  appId: '1:508557407988:web:b597b7784b1a90038850a1',
  measurementId: 'G-QBCT8WGV3G',
};

export const firebaseApp = getApps().length ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(firebaseApp);

// Analytics is optional and is only initialized in supported browser contexts.
export const analyticsPromise =
  typeof window !== 'undefined'
    ? isSupported().then((supported) => (supported ? getAnalytics(firebaseApp) : null))
    : Promise.resolve(null);
